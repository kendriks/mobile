package com.example.zooapp.models

import com.example.zooapp.R


data class Animal (
    val id: Int,
    val name: String,
    val species: String,
    val imageRes: Int,
    val description: String,
    val curiosities: String,
    var isFavorite: Boolean = false
)

val animalList = listOf(
    Animal(
        id = 1,
        name = "Dog",
        species = "Canis lupus familiaris",
        imageRes = R.drawable.dog,
        description = "O cão é um dos animais mais antigos domesticados pelo homem.",
        curiosities = "Os cães têm um olfato cerca de 40 vezes mais potente que o dos humanos."
    ),
    Animal(
        id = 2,
        name = "Cat",
        species = "Felis catus",
        imageRes = R.drawable.cat,
        description = "O gato doméstico é conhecido por sua agilidade e independência.",
        curiosities = "Gatos passam cerca de 70% do dia dormindo."
    ),
    Animal(
        id = 3,
        name = "Elephant",
        species = "Loxodonta africana",
        imageRes = R.drawable.elephant,
        description = "O elefante africano é o maior animal terrestre do planeta.",
        curiosities = "As orelhas dos elefantes ajudam a regular sua temperatura corporal."
    ),

    Animal(
        id = 4,
        name = "Penguin",
        species = "Aptenodytes forsteri",
        imageRes = R.drawable.penguin,
        description = "Os pinguins são aves que não voam e vivem predominantemente no Hemisfério Sul.",
        curiosities = "Os pinguins podem nadar a uma velocidade de até 25 km/h."
    ),

    Animal(
        id = 5,
        name = "Dolphin",
        species = "Delphinus delphis",
        imageRes = R.drawable.dolphin,
        description = "Os golfinhos são mamíferos marinhos altamente inteligentes e sociais.",
        curiosities = "Os golfinhos usam ecolocalização para navegar e encontrar alimentos."
    ),

    Animal(
        id = 6,
        name = "Tiger",
        species = "Panthera tigris",
        imageRes = R.drawable.tiger,
        description = "O tigre é o maior felino selvagem, conhecido por suas listras distintas.",
        curiosities = "Cada tigre tem um padrão de listras único, como uma impressão digital."
    )
)
